# NovelShare Demo

Small demo that scaffolds a minimal backend (Express) and a static frontend to show interactive buttons (Follow, Favorite, Read, Edit Profile).

Quick start (PowerShell):

```powershell
cd 'C:\Users\Jam\Desktop\novel'
npm install
npm start
# open http://localhost:3000 in a browser
```

Notes:
 - The server keeps in-memory state (resets on restart).
 - There is a dedicated page for creating new works: `/newbook.html`. The inline "New Work" form was removed and the tile in "Your Works" opens this page.
 - There is a dedicated page for creating new works: `/newbook.html`. The inline "New Work" form was removed and the tile in "Your Works" opens this page. Note: `newbook.html` asks for a Title and Cover (optional); the Author field was removed and chapter creation now includes content.
- Endpoints summary: `GET /api/books`, `POST /api/books` (create a book — supports `chapters` array), `GET /api/book/:id`, `POST /api/favorite/:id`, `POST /api/read/:id`, `POST /api/library/:id` (toggle library), `GET /api/reviews/:id`, `POST /api/review/:id`, `POST /api/follow`, `POST /api/profile/edit`, `GET /api/state`.
 - `POST /api/profile/avatar` (accepts JSON { avatar: '<dataUrl>' }) — store base64 data URL in-profile for demo (client-side upload).
 - `POST /api/profile/cover` (accepts JSON { cover: '<dataUrl>' }) — store base64 data URL in-profile for demo (client-side upload for cover image).
- Chapter endpoints: `POST /api/book/:id/chapters` (add { title, content }), `PUT /api/book/:id/chapters/:chapterId` (edit { title?, content? }), `DELETE /api/book/:id/chapters/:chapterId` (delete), `GET /api/book/:id/chapters/:chapterId` (fetch).

UI: In the demo UI you can create a new Work with initial chapters: click "New Work", fill Title/Author/Cover, add chapters using the "Add Chapter" UI, then click Create; the new book opens immediately and shows its chapters.
