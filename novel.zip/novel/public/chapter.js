function qsp(name){
  const url = new URL(location.href);
  return url.searchParams.get(name);
}

async function api(path, opts = {}){
  const res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  return res.json();
}

function $(id){ return document.getElementById(id); }

async function render(){
  const bookId = qsp('book') || '1';
  const chapId = qsp('chapter');
  if (!chapId) { $('chapter-title').textContent = 'No chapter selected'; return; }
  const c = await api(`/book/${bookId}/chapters/${chapId}`);
  const book = await api(`/book/${bookId}`);
  $('chapter-title').textContent = c.chapter;
  $('parent-book').textContent = `Book: ${book.title}`;
  $('chapter-content').textContent = c.content || '(No content)';

  $('btn-delete-chapter').onclick = async () => {
    if (!confirm('Delete this chapter?')) return;
    try {
      await api(`/book/${bookId}/chapters/${chapId}`, { method: 'DELETE' });
    } catch (err) {
      alert('Error deleting chapter: ' + err.message);
      return;
    }

    location.href = `/book.html?id=${bookId}`;
  };

  const editBtn = $('btn-edit-chapter');
  const editForm = $('chapter-edit-form');
  const editTitle = $('edit-chapter-title');
  const editContent = $('edit-chapter-content');
  const saveBtn = $('btn-save-chapter');
  const cancelBtn = $('btn-cancel-chapter');
  editBtn.onclick = () => {
    editForm.style.display = 'block';
    editTitle.value = c.chapter;
    editContent.value = c.content || '';
  };
  cancelBtn.onclick = () => { editForm.style.display = 'none'; };
  saveBtn.onclick = async () => {
    const newTitle = editTitle.value.trim();
    const newContent = editContent.value;
    if (!newTitle && !newContent) { alert('Please enter a title or content'); return; }
    try {
      await api(`/book/${bookId}/chapters/${chapId}`, { method: 'PUT', body: JSON.stringify({ title: newTitle, content: newContent }) });
    } catch (err) {
      alert('Error saving chapter changes: ' + err.message);
      return;
    }
    editForm.style.display = 'none';
    await render();
  };

  $('btn-add-chapter').onclick = () => { $('new-chapter-title').focus(); };
  $('btn-add-chapter-2').onclick = async () => {
    const t = $('new-chapter-title').value.trim();
    const cContent = $('new-chapter-content-2').value || '';
    if (!t) { alert('Enter a title'); return; }
    try { await api(`/book/${bookId}/chapters`, { method: 'POST', body: JSON.stringify({ title: t, content: cContent }) }); } catch (err) { alert('Error creating chapter: ' + err.message); return; }
    $('new-chapter-title').value = '';
    $('new-chapter-content-2').value = '';

    const refreshedBook = await api(`/book/${bookId}`);
    const last = refreshedBook.chapters[refreshedBook.chapters.length - 1];
    location.href = `/chapter.html?book=${bookId}&chapter=${last.id}`;
  };
}

window.addEventListener('DOMContentLoaded', render);
