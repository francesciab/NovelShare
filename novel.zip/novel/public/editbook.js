async function api(path, opts = {}) {
  const res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch(e) {}
  if (!res.ok) throw new Error(json && json.error ? json.error : text || res.statusText);
  return json || {};
}

function qsp(name){ const u = new URL(location.href); return u.searchParams.get(name); }
function $id(id){ return document.getElementById(id); }

async function render(){
  const id = qsp('id'); if (!id) return;
  const b = await api(`/book/${id}`);
  $id('eb-title').value = b.title || '';
  $id('eb-about').value = b.about || '';
  $id('eb-cover-preview').src = b.cover || 'https://placehold.co/140x200?text=Cover';
}

window.addEventListener('DOMContentLoaded', ()=>{
  const id = qsp('id'); if (!id) { alert('Missing book id'); location.href = '/'; return; }
  render();
  $id('eb-cancel').addEventListener('click', ()=> location.href = `/book.html?id=${id}`);
  $id('eb-save').addEventListener('click', async ()=>{
    const title = $id('eb-title').value.trim();
    const about = $id('eb-about').value.trim();
    try { await api(`/book/${id}`, { method: 'PUT', body: JSON.stringify({ title, about }) }); alert('Saved'); location.href = `/book.html?id=${id}`; } catch (err) { alert('Error saving: ' + err.message); }
  });

  const coverPreview = $id('eb-cover-preview');
  const coverInput = $id('eb-cover-input');
  coverPreview.style.cursor = 'pointer';
  coverPreview.addEventListener('click', ()=> coverInput.click());
  coverInput.addEventListener('change', async (e)=>{
    const file = e.target.files && e.target.files[0]; if (!file) return; if (!file.type.startsWith('image/')) { alert('Select an image'); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image(); img.onload = async () => {
        const width = 140, height = 200;
        const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
        const ctx = canvas.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0,0,width,height);
        const scale = Math.max(width/img.width, height/img.height); const sWidth = width/scale, sHeight = height/scale;
        const sx = Math.max(0, (img.width - sWidth)/2), sy = Math.max(0, (img.height - sHeight)/2);
        ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/png');
        try { await api(`/book/${id}`, { method: 'PUT', body: JSON.stringify({ cover: dataUrl }) }); coverPreview.src = dataUrl; alert('Cover updated'); } catch (err) { alert('Error uploading cover: ' + err.message); }
      };
      img.onerror = () => alert('Unable to load image');
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
});
