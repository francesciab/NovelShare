async function api(path, opts = {}) {
  const res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch(e) {}
  if (!res.ok) throw new Error(json && json.error ? json.error : text || res.statusText);
  return json || {};
}

function $id(id){ return document.getElementById(id); }

async function render() {
  const s = await api('/state');
  const p = s.profile || {};
  $id('profile-username').value = p.username || '';
  $id('profile-handle').value = p.handle || '';
  $id('profile-bio').value = p.bio || '';
  $id('profile-avatar').src = p.avatar || 'https://placehold.co/128x128';
  const coverPreview = $id('profile-cover-preview');
  if (coverPreview) coverPreview.src = p.cover || 'https://placehold.co/1100x240';
}

window.addEventListener('DOMContentLoaded', ()=>{
  render();

  $id('btn-cancel').addEventListener('click', ()=>{ location.href = '/'; });
  $id('btn-save-profile').addEventListener('click', async ()=>{
    const username = $id('profile-username').value.trim();
    const handle = $id('profile-handle').value.trim();
    const bio = $id('profile-bio').value.trim();
    try {
      await api('/profile/edit', { method: 'POST', body: JSON.stringify({ username, handle, bio }) });
      alert('Profile saved');
      location.href = '/';
    } catch (err) { alert('Error saving profile: ' + err.message); }
  });

  const avatar = $id('profile-avatar');
  const inFile = $id('profile-avatar-input');
  avatar.style.cursor = 'pointer';
  avatar.addEventListener('click', () => inFile.click());
  inFile.addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert('Please select an image file'); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = async () => {
        const size = 128;
        const canvas = document.createElement('canvas');
        canvas.width = size; canvas.height = size;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0,0,size,size);
        const scale = Math.max(size / img.width, size / img.height);
        const sWidth = size / scale;
        const sHeight = size / scale;
        const sx = Math.max(0, (img.width - sWidth) / 2);
        const sy = Math.max(0, (img.height - sHeight) / 2);
        ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, size, size);
        const dataUrl = canvas.toDataURL('image/png');
        try {
          await api('/profile/avatar', { method: 'POST', body: JSON.stringify({ avatar: dataUrl }) });
          avatar.src = dataUrl;
        } catch (err) { alert('Error uploading avatar: ' + err.message); }
      };
      img.onerror = () => alert('Unable to load image');
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
  const cPreview = $id('profile-cover-preview');
  const cInput = $id('profile-cover-input');
  if (cPreview && cInput) {
    cPreview.style.cursor = 'pointer';
    cPreview.addEventListener('click', () => cInput.click());
    cInput.addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      if (!file.type.startsWith('image/')) { alert('Please select an image file'); return; }
      const reader2 = new FileReader();
      reader2.onload = () => {
        const img2 = new Image();
        img2.onload = async () => {
          const width = 1100; const height = 240;
          const canvas = document.createElement('canvas');
          canvas.width = width; canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.fillStyle = '#fff'; ctx.fillRect(0,0,width,height);
          const scale = Math.max(width / img2.width, height / img2.height);
          const sWidth = width / scale; const sHeight = height / scale;
          const sx = Math.max(0, (img2.width - sWidth) / 2);
          const sy = Math.max(0, (img2.height - sHeight) / 2);
          ctx.drawImage(img2, sx, sy, sWidth, sHeight, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/png');
          try {
            await api('/profile/cover', { method: 'POST', body: JSON.stringify({ cover: dataUrl }) });
            cPreview.src = dataUrl;
          } catch (err) { alert('Error uploading cover: ' + err.message); }
        };
        img2.onerror = () => alert('Unable to load image');
        img2.src = reader2.result;
      };
      reader2.readAsDataURL(file);
    });
  }
});