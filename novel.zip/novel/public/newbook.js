async function api(path, opts = {}) {
  const res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch(e) {}
  if (!res.ok) throw new Error(json && json.error ? json.error : text || res.statusText);
  return json || {};
}

function $(id){ return document.getElementById(id); }

window.addEventListener('DOMContentLoaded', () => {
  const btnAdd = $('nb-add-chapter');
  const chaptersList = $('nb-chapters-list');
  let chapters = [];

  if (btnAdd) {
    btnAdd.addEventListener('click', () => {
      const title = $('nb-chapter-title').value.trim();
      const content = $('nb-chapter-content').value.trim();
      if (!title) { alert('Please enter a chapter title'); return; }
      const chap = { title, content };
      chapters.push(chap);
      const row = document.createElement('div');
      row.style.display = 'flex'; row.style.justifyContent = 'space-between'; row.style.alignItems = 'center'; row.style.border = '1px solid #eee'; row.style.padding = '8px'; row.style.borderRadius = '6px';
      row.innerHTML = `<div style='flex:1'><strong>${title}</strong><div style="color:var(--muted);font-size:12px">${content ? content.substring(0,140) + (content.length>140?'...':'') : '(no content)'}</div></div>`;
      const del = document.createElement('button'); del.className = 'btn-outline'; del.textContent = 'Remove';
      del.addEventListener('click', () => { chapters = chapters.filter(c => c !== chap); chaptersList.removeChild(row); });
      row.appendChild(del);
      chaptersList.appendChild(row);
      $('nb-chapter-title').value = '';
      $('nb-chapter-content').value = '';
    });
  }

  $('nb-create').addEventListener('click', async () => {
    const title = $('nb-title').value.trim();
    const cover = $('nb-cover').value.trim() || 'https://placehold.co/120x180?text=Cover';
    if (!title) { alert('Title is required'); return; }
    try {
      const res = await api('/books', { method: 'POST', body: JSON.stringify({ title, cover, chapters }) });
  
      location.href = `/book.html?id=${res.id}`;
    } catch (err) {
      alert('Error creating book: ' + err.message);
    }
  });

  $('nb-cancel').addEventListener('click', () => { location.href = '/'; });
});
