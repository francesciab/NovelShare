function qs(name){
  const u = new URL(location.href);
  return u.searchParams.get(name);
}

async function api(path, opts = {}){
  const res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch(e) {}
  if (!res.ok) throw new Error(json && json.error ? json.error : text || res.statusText);
  return json || {};
}

function el(html){ const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }

async function render(){
  const id = qs('id') || '1';
  const b = await api(`/book/${id}`);

  const coverImgElem = document.getElementById('cover-img');
  if (coverImgElem) coverImgElem.src = b.cover || 'https://placehold.co/140x200?text=Cover';
  document.getElementById('book-title').textContent = b.title;
  document.getElementById('book-author').textContent = `Author: ${b.author}`;
  document.getElementById('book-about').textContent = b.about;
  document.getElementById('book-stats').textContent = `Favorites: ${b.favorites} · Reads: ${b.reads}`;

  const reviews = document.getElementById('reviews');
  reviews.innerHTML = '';

  const rv = await api(`/reviews/${id}`);
  (rv||[]).forEach(r => {
    const box = el(`<div style="border:1px solid #eee;padding:12px;border-radius:6px;margin-top:12px"><strong>${r.author}</strong><div style="color:var(--muted);font-size:12px">${r.ago}</div><div style="margin-top:8px">${'★'.repeat(r.rating||5)}</div><p style="margin-top:8px">${r.text}</p></div>`);
    reviews.appendChild(box);
  });

  const toc = document.getElementById('toc-columns');
  toc.innerHTML = '';
  const half = Math.ceil(b.chapters.length / 2);
  const col1 = document.createElement('div'); col1.className = 'toc-column';
  const col2 = document.createElement('div'); col2.className = 'toc-column';

  const renderChapterRow = (c) => {
    const row = document.createElement('div');
    row.className = 'chapter';
    row.style.display = 'flex';
    row.style.justifyContent = 'space-between';
    row.style.alignItems = 'center';
    const title = document.createElement('div');
    title.textContent = c.chapter;
    title.style.flex = '1';
    const actions = document.createElement('div');
    actions.style.display = 'flex';
    actions.style.gap = '8px';

    const editBtn = document.createElement('button');
    editBtn.textContent = 'Edit';
    editBtn.className = 'btn-outline';
    editBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      const newTitle = prompt('Edit chapter title', c.chapter);
      if (!newTitle) return;
      try {
        await api(`/book/${id}/chapters/${c.id}`, { method: 'PUT', body: JSON.stringify({ title: newTitle }) });
      } catch (err) {
        alert('Error updating chapter: ' + err.message);
      }
      await render();
    });

    const delBtn = document.createElement('button');
    delBtn.textContent = 'Delete';
    delBtn.className = 'btn-outline';
    delBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      if (!confirm('Delete this chapter?')) return;
      try {
        await api(`/book/${id}/chapters/${c.id}`, { method: 'DELETE' });
      } catch (err) {
        alert('Error deleting chapter: ' + err.message);
      }
      await render();
    });
    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    row.appendChild(title);
    row.appendChild(actions);
    return row;
  };
  b.chapters.slice(0, half).forEach(c => { 
    const row = renderChapterRow(c);

    row.querySelector('div').style.cursor = 'pointer';
    row.querySelector('div').addEventListener('click', () => { location.href = `/chapter.html?book=${id}&chapter=${c.id}`; });
    col1.appendChild(row);
  });
  b.chapters.slice(half).forEach(c => { 
    const row = renderChapterRow(c);
    row.querySelector('div').style.cursor = 'pointer';
    row.querySelector('div').addEventListener('click', () => { location.href = `/chapter.html?book=${id}&chapter=${c.id}`; });
    col2.appendChild(row);
  });
  toc.appendChild(col1); toc.appendChild(col2);

  document.getElementById('btn-read').addEventListener('click', async ()=>{
    try { await api(`/read/${id}`, { method: 'POST' }); } catch (err) { alert('Error marking as read: ' + err.message); return; }
    const s = await api(`/book/${id}`);
    document.getElementById('book-stats').textContent = `Favorites: ${s.favorites} · Reads: ${s.reads}`;
    alert('Opening reader (demo) — read count incremented.');
  });

  const addBtn = document.getElementById('btn-add');
  if (addBtn) {
    addBtn.textContent = b.inLibrary ? 'In Library' : 'Add to Library';
    addBtn.addEventListener('click', async () => {
      try {
        const json = await api(`/library/${id}`, { method: 'POST' });
        
        addBtn.textContent = json.inLibrary ? 'In Library' : 'Add to Library';
      } catch (e) {
        alert('Error saving to library: ' + (e.message || e));
      }
    });
  }

  const editBtn = document.getElementById('btn-edit-book');
  if (editBtn) editBtn.addEventListener('click', () => { location.href = `/editbook.html?id=${id}`; });

  const btnPost = document.getElementById('btn-submit-review');
  if (btnPost) {
      btnPost.addEventListener('click', async ()=>{
        const author = document.getElementById('review-author').value || 'Anonymous';
        const text = document.getElementById('review-text').value;
        const rating = parseInt(document.getElementById('review-rating').value || '5', 10);
        if (!text) { alert('Please write a review.'); return; }
        try { await api(`/review/${id}`, { method: 'POST', body: JSON.stringify({ author, text, rating }) }); } catch (err) { alert('Error posting review: ' + err.message); return; }

        const rv2 = await api(`/reviews/${id}`);
      const reviews2 = document.getElementById('reviews');
      reviews2.innerHTML = '';
      (rv2||[]).forEach(r => {
        const box = el(`<div style="border:1px solid #eee;padding:12px;border-radius:6px;margin-top:12px"><strong>${r.author}</strong><div style="color:var(--muted);font-size:12px">${r.ago}</div><div style="margin-top:8px">${'★'.repeat(r.rating||5)}</div><p style="margin-top:8px">${r.text}</p></div>`);
        reviews2.appendChild(box);
      });

      document.getElementById('review-text').value = '';
    });
  }

  const btnAddChapter = document.getElementById('btn-add-chapter');
  if (btnAddChapter) {
      btnAddChapter.onclick = async () => {
      const t = document.getElementById('new-chapter-title').value;
      const c = document.getElementById('new-chapter-content').value || '';
      if (!t || !t.trim()) { alert('Please enter a title'); return; }
      try {
        await api(`/book/${id}/chapters`, { method: 'POST', body: JSON.stringify({ title: t.trim(), content: c }) });
      } catch (err) {
        alert('Error creating chapter: ' + err.message);
        return;
      }
      document.getElementById('new-chapter-title').value = '';
      document.getElementById('new-chapter-content').value = '';
      await render();
    };
  }

  const coverImg = document.getElementById('cover-img');
  const coverInput = document.getElementById('book-cover-input');
  if (coverImg && coverInput) {
    coverImg.style.cursor = 'pointer';
    coverImg.addEventListener('click', () => coverInput.click());
    coverInput.addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      if (!file.type.startsWith('image/')) { alert('Please select an image file'); return; }
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = async () => {
          const width = 140; const height = 200;
          const canvas = document.createElement('canvas');
          canvas.width = width; canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.fillStyle = '#fff'; ctx.fillRect(0,0,width,height);
          const scale = Math.max(width / img.width, height / img.height);
          const sWidth = width / scale; const sHeight = height / scale;
          const sx = Math.max(0, (img.width - sWidth) / 2);
          const sy = Math.max(0, (img.height - sHeight) / 2);
          ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/png');
          try {
            await api(`/book/${id}`, { method: 'PUT', body: JSON.stringify({ cover: dataUrl }) });
            coverImg.src = dataUrl;

          } catch (err) { alert('Error uploading book cover: ' + err.message); }
        };
        img.onerror = () => alert('Unable to load selected image');
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }
}

window.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('tab-about').addEventListener('click', ()=>{
    document.getElementById('panel-about').style.display = '';
    document.getElementById('panel-toc').style.display = 'none';
    document.getElementById('tab-about').classList.add('active');
    document.getElementById('tab-toc').classList.remove('active');
  });
  document.getElementById('tab-toc').addEventListener('click', ()=>{
    document.getElementById('panel-about').style.display = 'none';
    document.getElementById('panel-toc').style.display = '';
    document.getElementById('tab-toc').classList.add('active');
    document.getElementById('tab-about').classList.remove('active');
  });
  render();
});
