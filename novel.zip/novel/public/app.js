async function api(path, opts = {}) {
  const res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch(e){ /* not JSON */ }
  if (!res.ok) throw new Error(json && json.error ? json.error : text || res.statusText);
  return json || {};
}

function $(id){ return document.getElementById(id); }

async function renderWorks(mode = 'all', query = ''){
  const container = $('works-grid');
  if (!container) return;
  container.innerHTML = '<div style="color:var(--muted)">Loading…</div>';
  const books = await api('/books');
  const withState = await Promise.all(books.map(async b => {
    try { return await api(`/book/${b.id}`); } catch(e) { return b; }
  }));

  let filtered = mode === 'favs' ? withState.filter(b => b.favorited) : mode === 'library' ? withState.filter(b => b.inLibrary) : withState;

  if (query && query.trim()) {
    const q = query.trim().toLowerCase();
    filtered = filtered.filter(b => (b.title && b.title.toLowerCase().includes(q)) || (b.author && b.author.toLowerCase().includes(q)));
  }


  container.innerHTML = '';
  if (mode === 'all') {
    const newCard = document.createElement('div');
    newCard.className = 'new-work-card';
    newCard.setAttribute('role', 'button');
    newCard.setAttribute('tabindex', '0');
    newCard.setAttribute('aria-label', 'Create new work');
    newCard.innerHTML = `<div style="text-align:center"><div class="plus">+</div><div class="label">Create New Work</div></div>`;
    const openNewBookPage = () => { location.href = '/newbook.html'; };
    newCard.addEventListener('click', openNewBookPage);
    newCard.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openNewBookPage(); } });
    container.appendChild(newCard);
  }
  if (filtered.length === 0) {
    container.innerHTML = `<div style="color:var(--muted)">No books to show.</div>`;
    return;
  }

  filtered.forEach(b => {
    const card = document.createElement('div');
    card.className = 'book-card';
    const a = document.createElement('a');
    a.href = `/book.html?id=${b.id}`;
    a.innerHTML = `<img src="${b.cover}" alt="cover"><div class="book-title">${b.title}</div>`;
    card.appendChild(a);

    const favBtn = document.createElement('button');
    favBtn.className = 'fav-toggle';
    favBtn.textContent = b.favorited ? '♥' : '♡';
    favBtn.title = 'Toggle Favorite';
    favBtn.addEventListener('click', async (e) => {
      e.preventDefault(); e.stopPropagation();
      let js;
      try { js = await api(`/favorite/${b.id}`, { method: 'POST' }); } catch (err) { alert('Error toggling favorite: ' + err.message); return; }
      favBtn.textContent = js.favorited ? '♥' : '♡';

      const modeNow = $('tab-favs').classList.contains('active') ? 'favs' : $('tab-library') && $('tab-library').classList.contains('active') ? 'library' : 'all';
      renderWorks(modeNow, document.getElementById('search-box') ? document.getElementById('search-box').value : '');
    });

    const libBtn = document.createElement('button');
    libBtn.className = 'fav-toggle';
    libBtn.style.marginLeft = '6px';
    libBtn.textContent = b.inLibrary ? '✓' : '+';
    libBtn.title = 'Add to Library';
    libBtn.addEventListener('click', async (e) => {
      e.preventDefault(); e.stopPropagation();
      let body;
      try { body = await api(`/library/${b.id}`, { method: 'POST' }); } catch (err) { alert('Error toggling library: ' + err.message); return; }
      libBtn.textContent = body.inLibrary ? '✓' : '+';
      const modeNow = $('tab-library') && $('tab-library').classList.contains('active') ? 'library' : $('tab-favs').classList.contains('active') ? 'favs' : 'all';
      renderWorks(modeNow, document.getElementById('search-box') ? document.getElementById('search-box').value : '');
    });

    const overlay = document.createElement('div');
    overlay.style.position = 'absolute';
    overlay.style.right = '8px';
    overlay.style.top = '8px';
    overlay.appendChild(favBtn);
    overlay.appendChild(libBtn);


    if (b.inLibrary) {
      const libBadge = document.createElement('div');
      libBadge.textContent = 'In Library';
      libBadge.style.position = 'absolute';
      libBadge.style.left = '8px';
      libBadge.style.top = '8px';
      libBadge.style.background = 'rgba(255,255,255,0.95)';
      libBadge.style.padding = '4px 6px';
      libBadge.style.border = '1px solid #eee';
      libBadge.style.borderRadius = '6px';
      libBadge.style.fontSize = '11px';
      card.appendChild(libBadge);
    }

    const wrapper = document.createElement('div');
    wrapper.style.display = 'inline-block';
    wrapper.style.position = 'relative';
    wrapper.appendChild(card);
    wrapper.appendChild(overlay);

    container.appendChild(wrapper);
  });
}

async function refreshState(){
  const s = await api('/state');
  if ($('username')) $('username').textContent = s.profile.username;
  if ($('followers')) $('followers').textContent = s.profile.followers || 0;
  if ($('following')) $('following').textContent = s.profile.following ? 1 : 0;
  if ($('handle')) $('handle').textContent = s.profile.handle || '';
  if ($('bio')) $('bio').textContent = s.profile.bio || '';
  if ($('avatar')) $('avatar').src = s.profile.avatar || 'https://placehold.co/128x128';
  if ($('cover')) $('cover').style.backgroundImage = s.profile.cover ? `url('${s.profile.cover}')` : 'linear-gradient(var(--pink), #ffd3da)';

  renderWorks('all');
}

window.addEventListener('DOMContentLoaded', () => {

  const tabWorks = $('tab-works');
  const tabFavs = $('tab-favs');
  const tabLibrary = $('tab-library');
  if (tabWorks && tabFavs && tabLibrary) {
    tabWorks.addEventListener('click', () => { tabWorks.classList.add('active'); tabFavs.classList.remove('active'); tabLibrary.classList.remove('active'); renderWorks('all', document.getElementById('search-box') ? document.getElementById('search-box').value : ''); });
    tabFavs.addEventListener('click', () => { tabFavs.classList.add('active'); tabWorks.classList.remove('active'); tabLibrary.classList.remove('active'); renderWorks('favs', document.getElementById('search-box') ? document.getElementById('search-box').value : ''); });
    tabLibrary.addEventListener('click', () => { tabLibrary.classList.add('active'); tabWorks.classList.remove('active'); tabFavs.classList.remove('active'); renderWorks('library', document.getElementById('search-box') ? document.getElementById('search-box').value : ''); });

    const headerLibrary = $('header-library');
    const headerBrowse = $('header-browse');
    if (headerLibrary) headerLibrary.addEventListener('click', () => { tabLibrary.click(); });
    if (headerBrowse) headerBrowse.addEventListener('click', () => { tabWorks.click(); });
  }


  if ($('btn-edit')) $('btn-edit').addEventListener('click', async () => {
    location.href = '/profile.html';
  });

  const searchBox = $('search-box');
  if (searchBox) {
    searchBox.addEventListener('input', (e) => {
      const mode = $('tab-library') && $('tab-library').classList.contains('active') ? 'library' : $('tab-favs').classList.contains('active') ? 'favs' : 'all';
      renderWorks(mode, e.target.value);
    });
  }


  refreshState();
});
