# Copilot / AI contributor instructions for NovelShare demo

This file gives essential, actionable context for an AI coding assistant working in this repository. Keep it short and focused on discoverable patterns and where to make changes.

Project overview
- Minimal full-stack demo: an Express backend (`server.js`) serving static frontend files in `public/`.
- Purpose: demonstrate interactive UI buttons (Follow, Favorite, Read, Edit Profile) wired to simple JSON endpoints.

Key files
- `server.js`: main Express app and REST endpoints with in-memory state. Modify here for backend logic or persistence.
- `public/index.html`: single-page UI that matches the provided mock (profile header, cover text, book tile, actions).
- `public/app.js`: client-side wiring — fetch-based calls to `/api/*` endpoints and DOM updates. Use `refreshState()` when adding new interactions.
- `public/styles.css`: lightweight styling approximating the mock.
- `README.md`: how to run locally (PowerShell commands).

Architecture & data flow
- Browser -> fetch() -> Express endpoints. The server updates an in-memory `state` object and returns JSON. The client calls `GET /api/state` to re-sync UI after each action.
- No DB in this demo; persistence resets on server restart. For production, replace in-memory `state` in `server.js` with a database adapter and keep endpoint signatures intact.

Developer workflows
- Run locally: `npm install` then `npm start` (PowerShell example in `README.md`).
- Port is `3000` by default. To test endpoints directly use `curl` or the browser network inspector.

Project-specific conventions
- Simple REST verbs: `POST` for state-changing actions (`/api/follow`, `/api/favorite`, `/api/read`, `/api/profile/edit`) and `GET /api/state` to fetch current state.
 - Chapters: `POST /api/book/:id/chapters` (add), `PUT /api/book/:id/chapters/:chapterId` (edit), `DELETE /api/book/:id/chapters/:chapterId` (delete).
 - Books: `GET /api/books` (list), `GET /api/book/:id` (details), `POST /api/books` (create).
 - Books: `GET /api/books` (list), `GET /api/book/:id` (details), `POST /api/books` (create with `{ title, author, cover, chapters }` where `chapters` is an array of `{ title, content }`).
Examples
- Toggle follow: `POST /api/follow` flips `profile.following` boolean; client toggles `.active` on `#btn-follow`.
- Favorite: `POST /api/favorite` toggles `book.favorited` and increments/decrements `book.favorites`.
- Library: `POST /api/library/:id` toggles whether a book is in the user's library (demo in-memory only).
- Reviews: `GET /api/reviews/:id` and `POST /api/review/:id` return and add reviews for a book; review objects include a small author, text, rating and ago fields.

Testing hints
- No test harness included. Use the browser and DevTools: watch network calls and `GET /api/state` to verify server-side updates.

Limitations
- This repo is a demo scaffold. Replace in-memory state with a DB and add authentication for a production-ready app.

If something is unclear
- Ask what behavior should persist across restarts (DB vs in-memory), and whether authentication is required. Point modifications to `server.js` and `public/app.js`.
