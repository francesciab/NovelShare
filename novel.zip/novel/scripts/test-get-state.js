const http = require('http');

const options = {
  hostname: 'localhost',
  port: 4000,
  path: '/api/state',
  method: 'GET'
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Response:', body);
  });
});

req.on('error', (err) => console.error('Request error:', err));
req.end();
