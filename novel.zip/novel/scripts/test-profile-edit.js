const http = require('http');

const postData = JSON.stringify({ username: 'New Name', handle: '@noveluser', bio: 'Go explore' });

const options = {
  hostname: 'localhost',
  port: 4000,
  path: '/api/profile/edit',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  }
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('POST status:', res.statusCode);
    console.log('POST response:', body);

    http.get('http://localhost:4000/api/state', (res2) => {
      let body2 = '';
      res2.on('data', (chunk) => body2 += chunk);
      res2.on('end', () => {
        console.log('GET status:', res2.statusCode);
        console.log('GET response:', body2);
      });
    }).on('error', (err) => console.error('GET error', err));
  });
});

req.on('error', (err) => console.error('POST error:', err));
req.write(postData);
req.end();
