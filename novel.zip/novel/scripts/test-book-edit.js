const http = require('http');
const data = JSON.stringify({ title: 'Edited Title from Script', cover: 'https://placehold.co/120x180?text=Edited', about: 'Updated about via script' });

const options = {
  hostname: 'localhost',
  port: 4001,
  path: '/api/book/1',
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data)
  }
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Response:', body);
  });
});

req.on('error', (err) => console.error('Request error:', err));
req.write(data);
req.end();
