const http = require('http');
const tinyPngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNgYAAAAAMAASsJTYQAAAAASUVORK5CYII=';
const dataUrl = 'data:image/png;base64,' + tinyPngBase64;
const data = JSON.stringify({ cover: dataUrl });

const options = {
  hostname: 'localhost',
  port: 4001,
  path: '/api/book/1',
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data)
  }
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Response:', body);
    http.get('http://localhost:4001/api/book/1', (res2) => {
      let body2 = '';
      res2.on('data', (chunk) => body2 += chunk);
      res2.on('end', () => { console.log('GET book:', body2); });
    }).on('error', (err) => console.error('GET error', err));
  });
});

req.on('error', (err) => console.error('Request error:', err));
req.write(data);
req.end();
