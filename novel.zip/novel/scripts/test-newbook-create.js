const http = require('http');
const data = JSON.stringify({
  title: 'New Book From Script',
  cover: 'https://placehold.co/120x180?text=Script',
  chapters: [{ title: 'Intro', content: 'Scripted intro' }]
});

const options = {
  hostname: 'localhost',
  port: 4000,
  path: '/api/books',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data)
  }
};

const req = http.request(options, (res) => {
  let body = '';
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Response:', body);
    try {
      const json = JSON.parse(body);
      if (json && json.id) {
        http.get(`http://localhost:4000/api/book/${json.id}`, (res2) => {
          let body2 = '';
          res2.on('data', (chunk) => body2 += chunk);
          res2.on('end', () => {
            console.log('GET book status:', res2.statusCode);
            console.log('GET book response:', body2);
          });
        }).on('error', (err) => console.error('GET error', err));
      }
    } catch (e) { }
  });
});

req.on('error', (err) => console.error('Request error:', err));
req.write(data);
req.end();
