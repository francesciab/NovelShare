const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
// Allow larger JSON bodies to support base64 image uploads in demo (6MB max)
app.use(express.json({ limit: '6mb' }));

app.use(express.static(path.join(__dirname, 'public')));

const state = {
  profile: { username: 'user', handle: '@starlightwhisperer', bio: 'Life begins at the end of your comfort zone.', following: false, avatar: '', cover: '' }
};

const books = [
  {
    id: '1',
    title: 'I Made a Fortune by Marrying A Sickly Woman',
    author: 'Fan Que',
    cover: 'https://placehold.co/120x180?text=Cover',
    about: `In her previous life, Song Jin and her husband treated each other with respect and were harmonious in front of others, but in fact, she had a lot of pain that she could not express. Qin Mingsong had someone in her heart and did not want to consummate the marriage...`,
    chapters: Array.from({ length: 10 }).map((_, i) => ({
      chapter: `Chapter ${i + 1}: ${i % 2 === 0 ? 'Twin sisters' : 'Dobby is a free elf!'}`,
      content: `This is the content for chapter ${i + 1}.`,
      id: `c${i + 1}`
    })),
    reviews: [
      { id: 'r1', author: 'Arthur Weasley', text: 'I like the series and the characters flaws seem fairly minor compared to most.', rating: 5, ago: '20 days ago' }
    ]
  }
];

const bookState = books.reduce((acc, b) => {
  acc[b.id] = { favorites: 0, favorited: false, reads: 0, inLibrary: false };
  return acc;
}, {});

state.profile.followers = 0;
state.profile.following = false;


app.post('/api/follow', (req, res) => {
  state.profile.following = !state.profile.following;
  if (state.profile.following) state.profile.followers += 1; else state.profile.followers = Math.max(0, state.profile.followers - 1);
  res.json({ following: state.profile.following, followers: state.profile.followers });
});

app.post('/api/favorite', (req, res) => {
  const id = (req.body && req.body.id) || '1';
  const s = bookState[id];
  if (!s) return res.status(404).json({ error: 'book not found' });
  s.favorited = !s.favorited;
  s.favorites += s.favorited ? 1 : -1;
  if (s.favorites < 0) s.favorites = 0;
  res.json({ favorited: s.favorited, favorites: s.favorites });
});

app.post('/api/read', (req, res) => {
  const id = (req.body && req.body.id) || '1';
  const s = bookState[id];
  if (!s) return res.status(404).json({ error: 'book not found' });
  s.reads += 1;
  res.json({ reads: s.reads });
});

app.post('/api/profile/edit', (req, res) => {
  const { username, handle, bio } = req.body || {};
  if (username) state.profile.username = username;
  if (handle) state.profile.handle = handle;
  if (bio) state.profile.bio = bio;
  res.json({ profile: state.profile });
});

// POST /api/profile/avatar
app.post('/api/profile/avatar', (req, res) => {
  try {
    const { avatar } = req.body || {};
    if (!avatar || typeof avatar !== 'string') return res.status(400).json({ error: 'avatar is required' });
    // Basic validation to ensure it's a data URL (base64)
    if (!/^data:image\/.+;base64,/.test(avatar)) return res.status(400).json({ error: 'invalid avatar format' });
    // Optionally: enforce size limit ~ 1MB (data URL length > ~1.3MB depending on base64 overhead)
    const maxBytes = 1_200_000; // ~1.2MB
    const base64Size = Buffer.byteLength(avatar.split(',')[1] || '', 'base64');
    if (base64Size > maxBytes) return res.status(400).json({ error: 'avatar too large' });
    state.profile.avatar = avatar;
    console.log('Profile avatar updated, bytes:', base64Size);
    res.json({ profile: state.profile });
  } catch (err) {
    console.error('Error in POST /api/profile/avatar', err);
    res.status(500).json({ error: 'internal server error' });
  }
});

// POST /api/profile/cover
app.post('/api/profile/cover', (req, res) => {
  try {
    const { cover } = req.body || {};
    if (!cover || typeof cover !== 'string') return res.status(400).json({ error: 'cover is required' });
    if (!/^data:image\/.+;base64,/.test(cover)) return res.status(400).json({ error: 'invalid cover format' });
    const maxBytes = 3_000_000; // ~3MB for larger cover images
    const base64Size = Buffer.byteLength(cover.split(',')[1] || '', 'base64');
    if (base64Size > maxBytes) return res.status(400).json({ error: 'cover too large' });
    state.profile.cover = cover;
    console.log('Profile cover updated, bytes:', base64Size);
    res.json({ profile: state.profile });
  } catch (err) {
    console.error('Error in POST /api/profile/cover', err);
    res.status(500).json({ error: 'internal server error' });
  }
});
app.post('/api/books', (req, res) => {
  try {
    console.log('POST /api/books received', { body: req.body });
    const { title, author, cover, chapters } = req.body || {};
    if (!title) return res.status(400).json({ error: 'title is required' });
  const id = `${Date.now()}`;
  const newBook = { id, title, author: author || 'Unknown', cover: cover || 'https://placehold.co/120x180?text=Cover', about: '', chapters: [], reviews: [] };
    let chaptersArr = [];
    if (Array.isArray(chapters)) chaptersArr = chapters;
    else if (typeof chapters === 'string') {
      try { chaptersArr = JSON.parse(chapters); } catch (e) { chaptersArr = []; }
    }
    if (Array.isArray(chaptersArr) && chaptersArr.length) {
      newBook.chapters = chaptersArr.map((c, idx) => ({ id: `c${Date.now()}_${idx}`, chapter: c.title || 'Untitled', content: c.content || '' }));
      console.log(`Creating book ${title} with ${newBook.chapters.length} chapters`);
    }
    books.push(newBook);
    bookState[id] = { favorites: 0, favorited: false, reads: 0, inLibrary: false };
    console.log('Book created:', newBook.id, newBook.title);
    return res.status(201).json(newBook);
  } catch (err) {
    console.error('Error in POST /api/books', err);
    return res.status(500).json({ error: 'internal server error' });
  }
});

app.get('/api/state', (req, res) => {
  console.log('GET /api/state');
  res.json({ profile: state.profile });
});

app.get('/api/books', (req, res) => {
  const list = books.map(b => {
    const s = bookState[b.id] || { favorites: 0, favorited: false, reads: 0, inLibrary: false };
    return { id: b.id, title: b.title, author: b.author, cover: b.cover, inLibrary: s.inLibrary, favorited: s.favorited, favorites: s.favorites };
  });
  console.log(`GET /api/books -> ${list.length} book(s)`);
  res.json(list);
});


app.get('/api/book/:id', (req, res) => {
  const b = books.find(x => x.id === req.params.id);
  if (!b) return res.status(404).json({ error: 'not found' });

  const s = bookState[b.id] || { favorites: 0, favorited: false, reads: 0 };
  const bookStateOut = { ...b, favorites: s.favorites, favorited: s.favorited, reads: s.reads };
  res.json(bookStateOut);
});

// Edit a book - PUT /api/book/:id
app.put('/api/book/:id', (req, res) => {
  const id = req.params.id;
  const b = books.find(x => x.id === id);
  if (!b) return res.status(404).json({ error: 'book not found' });
  const { title, cover, about } = req.body || {};
  if (!title && !cover && !about) return res.status(400).json({ error: 'title, cover or about required' });
  if (title) b.title = title;
  if (cover) b.cover = cover;
  if (about) b.about = about;
  return res.json(b);
});

app.get('/api/book/:id/chapters/:chapterId', (req, res) => {
  const { id, chapterId } = req.params;
  const b = books.find(x => x.id === id);
  if (!b) return res.status(404).json({ error: 'book not found' });
  const ch = b.chapters.find(c => c.id === chapterId);
  if (!ch) return res.status(404).json({ error: 'chapter not found' });
  res.json(ch);
});

app.post('/api/book/:id/chapters', (req, res) => {
  const id = req.params.id;
  const b = books.find(x => x.id === id);
  if (!b) return res.status(404).json({ error: 'book not found' });
  const { title, content } = req.body || {};
  if (!title) return res.status(400).json({ error: 'title is required' });
  const newChapter = { id: `c${Date.now()}`, chapter: title, content: content || '' };
  b.chapters.push(newChapter);
  res.json(newChapter);
});

// Edit a chapter - PUT /api/book/:id/chapters/:chapterId
app.put('/api/book/:id/chapters/:chapterId', (req, res) => {
  const { id, chapterId } = req.params;
  const b = books.find(x => x.id === id);
  if (!b) return res.status(404).json({ error: 'book not found' });
  const ch = b.chapters.find(c => c.id === chapterId);
  if (!ch) return res.status(404).json({ error: 'chapter not found' });
  const { title, content } = req.body || {};
  if (!title && !('content' in req.body)) return res.status(400).json({ error: 'title or content is required' });
  if (title) ch.chapter = title;
  if ('content' in req.body) ch.content = content || '';
  res.json(ch);
});

app.delete('/api/book/:id/chapters/:chapterId', (req, res) => {
  const { id, chapterId } = req.params;
  const b = books.find(x => x.id === id);
  if (!b) return res.status(404).json({ error: 'book not found' });
  const idx = b.chapters.findIndex(c => c.id === chapterId);
  if (idx === -1) return res.status(404).json({ error: 'chapter not found' });
  b.chapters.splice(idx, 1);
  res.json({ success: true });
});

app.post('/api/favorite/:id', (req, res) => {
  const id = req.params.id;
  const s = bookState[id];
  if (!s) return res.status(404).json({ error: 'book not found' });
  s.favorited = !s.favorited;
  s.favorites += s.favorited ? 1 : -1;
  if (s.favorites < 0) s.favorites = 0;
  res.json({ favorited: s.favorited, favorites: s.favorites });
});

app.post('/api/library/:id', (req, res) => {
  const id = req.params.id;
  const s = bookState[id];
  if (!s) return res.status(404).json({ error: 'book not found' });
  s.inLibrary = !s.inLibrary;
  res.json({ inLibrary: s.inLibrary });
});

app.post('/api/read/:id', (req, res) => {
  const id = req.params.id;
  const s = bookState[id];
  if (!s) return res.status(404).json({ error: 'book not found' });
  s.reads += 1;
  res.json({ reads: s.reads });
});

app.get('/api/reviews/:id', (req, res) => {
  const id = req.params.id;
  const b = books.find(x => x.id === id);
  if (!b) return res.status(404).json({ error: 'book not found' });
  res.json(b.reviews || []);
});

app.post('/api/review/:id', (req, res) => {
  const id = req.params.id;
  const b = books.find(x => x.id === id);
  if (!b) return res.status(404).json({ error: 'book not found' });
  const { author, text, rating } = req.body || {};
  if (!text || !author) return res.status(400).json({ error: 'author & text required' });
  const r = { id: `r${Date.now()}`, author, text, rating: rating || 5, ago: 'Just now' };
  b.reviews = b.reviews || [];
  b.reviews.unshift(r);
  res.json(r);
});

const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use. Start the server with a different PORT, e.g. $env:PORT=4000; npm start`);
    process.exit(1);
  }
  console.error('Server error', err);
  process.exit(1);
});

process.on('SIGINT', () => {
  console.log('Shutting down server (SIGINT)');
  server.close(() => process.exit(0));
});
